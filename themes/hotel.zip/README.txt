Theme Information
-------------------------------------------------------------------------------

- Theme Version: 7.x-1.x-dev
- Released on: Aug 15, 2012
- Packaged on: Jun 13, 2014
- Compatible with Drupal 7.x
- Copyright (C) 2012-2014 WeebPal.com. All Rights Reserved.
- @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
- Author: WeebPal Team
- Website: http://www.weebpal.com
- Guide: http://weebpal.com/guides
- Twitter: http://twitter.com/weebpal
- Facebook: http://www.facebook.com/weebpal


Folder Structure
-------------------------------------------------------------------------------
- README.txt
- hotel-profile-7.x-1.x-dev.zip demo profile for Hotel
- hotel-7.x-1.x-dev.zip: Hotel theme


Installation
-------------------------------------------------------------------------------
From Demo profile package:
Step 1: Extract demo profile package to your host.
Step 2: Navigate to the folder you have extracted the zip file and install
  weebpal profile.

Theme only installation: 
Extract and copy the themes to themes folder and install.

